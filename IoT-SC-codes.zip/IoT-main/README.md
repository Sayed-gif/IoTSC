# IoT
Program for the course IoT for Smart City

This project is the early stage of IoT where we start by getting the data, store it and display it.
First, we will use an ESP32 microcontroler and sensors to collect temperature, humidity, pressure and gas data.
We will use InfluxDB to store the data and Grafana to visualize them on a dashboard.
These code will have to be implemented on Visual Studio Code.
